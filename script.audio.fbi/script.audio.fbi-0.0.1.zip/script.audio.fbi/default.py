import xbmcaddon, xbmc

xbmc.executebuiltin("PlayMedia(http://eno.emit.com:8000/fbi_live_64.aacp)")