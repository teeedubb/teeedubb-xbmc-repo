Stream Triple J radio online. Includes Triple J, Double J and Triple J Unearthed streams.
See: https://radio.abc.net.au/

http://forum.xbmc.org/showthread.php?tid=184488