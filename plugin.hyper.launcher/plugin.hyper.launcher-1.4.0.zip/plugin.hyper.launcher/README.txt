Hyper Launcher.
http://forum.kodi.tv/showthread.php?tid=258159
https://github.com/teeedubb/teeedubb-xbmc-repo/tree/master/plugin.hyper.launcher