import os
import xbmcaddon, xbmc

PlayMedia(http://www.abc.net.au/res/streaming/audio/aac/triplej.pls)