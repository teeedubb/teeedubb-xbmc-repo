Stream Triple J radio online. The addon uses the 96kbps AAC itunes stream. See: http://www.abc.net.au/triplej/media/listen.htm?show=listen#

http://forum.xbmc.org/showthread.php?tid=184488