import xbmcaddon, xbmc

xbmc.executebuiltin("PlayMedia(http://www.abc.net.au/res/streaming/audio/aac/triplej.pls)")