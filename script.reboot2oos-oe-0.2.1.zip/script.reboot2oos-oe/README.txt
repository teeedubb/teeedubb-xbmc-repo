reboot2oos-oe 

This addon will reboot your OpenELEC machine once into another OS of your choice then boot back into OpenELEC. It uses GRUB so a working multi-boot setup with GRUB is required - This wiki article shows how to set dual boot up and how to hide the GRUB menu. I'm using a minimal Ubuntu 12.04 install to configure GRUB - 1.5gb of hdd space is enough for this, probably even less is needed, I need to check this over time. This addon uses GRUB 2.00 and has been tested with GRUB 1.99 and 2.00. Updates to GRUB can break this addon.

Manual editing files contained within the zip is required to get this addon working (preferably before installation).

script.reboot2oos-oe\addon.xml

name=


Edit the name= tag to your liking. I currently have it named Games because I reboot into windows to play games and emulators.

script.reboot2oos-oe\default.py

if dialog.yesno("Reboot to windows...", "XBMC needs to reboot for Games"):


This is the message that is contained in the Yes/No dialog

script.reboot2oos-oe\bin\reboot2oos.sh

GRUB_BOOT_DIR=


This points to the location where the /boot folder that GRUB uses is located. My Ubuntu partition where GRUB's boot directory is located is labelled 'ubuntu' and is mounted at /media/ubuntu, so I use /media/ubuntu/boot.

GRUB_DEFAULT=
GRUB_REBOOT=

The numbers following the above options correspond to your GRUB menu entries and they start from 0, so in the included file my GRUB_DEFAULT= entry (6) is the main OS (Openelec) and is the 7th entry in the GRUB menu. GRUB_REBOOT=, the OS I wish to reboot once into (5) is the 6th GRUB menu entry.

script.reboot2oos-oe\icon.png

The addon icon can be changed based on your needs. It is currently a Atari 2600 joystick as I reboot into windows to play games.

Install the addon. i386 users need to run the following command once after installing the addon before the addon will work:

mv /storage/.xbmc/addons/script.reboot2oos-oe/grub-i386/* /storage/.xbmc/addons/script.reboot2oos-oe/


Reboot to your your Ubuntu install (Or whatever OS you choose to use for GRUB) you need to edit /etc/default/grub and change the line

GRUB_DEFAULT=

to

GRUB_DEFAULT=saved


then exit and run

sudo update-grub 
sudo grub-set-default 6 #change number to OpenELEC GRUB menu entry number
sudo reboot


You should now be back in OpenELEC (or what ever GRUB entry you selected as default). Now select 'Games' under Programs to use the addon and reboot once to the OS of your choice.


Reboot2oos-oe
http://openelec.tv/forum/128-addons/62352-addon-reboot-once-to-another-os#62765

See this wiki article for info on how to setup dual boot with GRUB and hide the GRUB menu.
http://wiki.openelec.tv/index.php?title=Config_dualboot


by teeedubb





Compiling GRUB 2.00 for OE on ubuntu 14.04

sudo apt-get build-dep grub2

wget ftp://ftp.gnu.org/gnu/grub/grub-2.00.tar.gz

tar -xvf grub-2.00.tar.gz

cd grub-2.00/

sed -i -e '/gets is a security/d' grub-core/gnulib/stdio.in.h

./configure -prefix=/storage/.kodi/addons/script.reboot2oos-oe --sbindir=/storage/.kodi/addons/script.reboot2oos-oe/bin --disable-grub-mkfont

make -j4

cp grub-reboot grub-set-default grub-editenv ~/Desktop/script.reboot2oos-oe/bin/

cp grub-mkconfig_lib ~/Desktop/script.reboot2oos-oe/share/grub/

#following is for x86 grub

make clean

./configure -prefix=/storage/.kodi/addons/script.reboot2oos-oe --sbindir=/storage/.kodi/addons/script.reboot2oos-oe/bin --host=i686 --disable-grub-mkfont

cp grub-reboot grub-set-default grub-editenv ~/Desktop/script.reboot2oos-oe/grub-i386/bin/

cp ./grub-mkconfig_lib ~/Desktop/script.reboot2oos-oe/grub-i386/share/grub/

OR to install:

cp grub-reboot grub-set-default grub-editenv ~/Desktop/script.reboot2oos-oe/bin/

cp grub-mkconfig_lib ~/Desktop/script.reboot2oos-oe/share/grub/