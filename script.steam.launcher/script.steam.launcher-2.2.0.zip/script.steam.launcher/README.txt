Steam Launcher - Start Steam Big Picture Mode from within XBMC
See XBMC thread for more details:
http://forum.xbmc.org/showthread.php?tid=157499

https://github.com/teeedubb
http://store.steampowered.com/bigpicture
http://xbmc.org/