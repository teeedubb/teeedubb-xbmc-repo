script.audio.party.mode.start

Starts Music Party Mode, waits for X seconds then switches to full screen visualisation and optionally toggles the fullscreen music info after X seconds and will indefinitely play random songs from your music collection. Timeouts can be configured in addon settings, defaults are 5 seconds for each.