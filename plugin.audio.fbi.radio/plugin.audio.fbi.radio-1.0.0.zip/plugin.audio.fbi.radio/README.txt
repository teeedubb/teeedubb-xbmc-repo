Stream fbi radio online. 

See: 
http://fbiradio.com/on-air-now/

http://forum.xbmc.org/showthread.php?tid=184488