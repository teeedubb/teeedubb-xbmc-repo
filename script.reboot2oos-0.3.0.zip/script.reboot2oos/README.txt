reboot2oos by teeedubb 

This addon will reboot your machine once into another OS of your choice then boot back into your default OS. It uses GRUB so a working multi-boot setup with GRUB is required. This addon has been tested with GRUB 1.99 and 2.00. Updates to GRUB can break this addon.

Manual editing files contained within the zip is required to get this addon working (preferably before installation).

script.reboot2oos\addon.xml

name=

Edit the name= tag to your liking. I currently have it named Games because I reboot into windows to play games and emulators.


script.reboot2oos\default.py

if dialog.yesno("Reboot to windows...", "XBMC needs to reboot for Games"):

This is the message that is contained in the Yes/No dialog


script.reboot2oos\reboot2oos.sh

REBOOT_TO=
DEFAULT_OS=

The entries following the above options correspond to your GRUB menu entries - REBOOT_TO= is the OS you want to reboot once to, DEFAULT_OS= is your default OS. 
You can get a listing of OS's recognised by GRUB with the following command:

sed -n '/menuentry/s/.*\(["'\''].*["'\'']\).*/\1/p' /boot/grub/grub.cfg


script.reboot2oos\icon.png

The addon icon can be changed based on your needs. It is currently a Atari 2600 joystick as I reboot into windows to play games.

Install the addon and edit the file /etc/default/grub and change the line

GRUB_DEFAULT=

to

GRUB_DEFAULT=saved


then exit and now you need to edit the sudoers file so the commands that require root can run without a password:

sudo visudo

At the end of the file after #includedir /etc/sudoers.d add (note you need to edit the username, mine is xbmc):

%xbmc ALL = NOPASSWD: /sbin/reboot, /usr/sbin/grub-set-default, /usr/sbin/grub-reboot

Now update GRUB and make the script executable:

sudo update-grub 
chmod +x ~/.xbmc/addons/script.reboot2oos/reboot2oos.sh

Now select 'Games' under Programs to use the addon and reboot once to the OS of your choice.


Reboot2oOS:
http://forum.xbmc.org/showthread.php?tid=172715

Openelec version: Reboot2oos-oe
http://openelec.tv/forum/128-addons/62352-addon-reboot-once-to-another-os#62765







Compiling GRUB 2.00 for OE


wget ftp://ftp.gnu.org/gnu/grub/grub-2.00.tar.gz

tar -xvf grub-2.00.tar.gz

cd grub-2.00/

sed -i -e '/gets is a security/d' grub-core/gnulib/stdio.in.h

./configure -prefix=/storage/.xbmc/addons/script.reboot2oos-oe --sbindir=/storage/.xbmc/addons/script.reboot2oos-oe/bin --build=x86_64

