#!/bin/bash
#Edit the lines between the #####'s
#Use the following command to list GRUB boot entries:
#sed -n '/menuentry/s/.*\(["'\''].*["'\'']\).*/\1/p' /boot/grub/grub.cfg
set -e

#####

REBOOT_TO="osprober-chain-6A6C4AD16C4A9829" #win7
DEFAULT_OS="gnulinux-simple-5c99d0a0-eb2f-456c-b8f3-51a6037d2850" #ubuntu

#####

GRUB_DEFAULT=$(sed -n '/menuentry/s/.*\(["'\''].*["'\'']\).*/\1/p' /boot/grub/grub.cfg |grep -F "$DEFAULT_OS" | tail -n1 | sed 's/^.\(.*\).$/\1/')
MENU_ENTRY=$(sed -n '/menuentry/s/.*\(["'\''].*["'\'']\).*/\1/p' /boot/grub/grub.cfg |grep -F "$REBOOT_TO" | tail -n1 | sed 's/^.\(.*\).$/\1/')
echo "GRUB default boot OS: $GRUB_DEFAULT"
echo "Reboot once to: $MENU_ENTRY"
sudo grub-set-default $GRUB_DEFAULT
sudo grub-reboot $MENU_ENTRY
sudo reboot
