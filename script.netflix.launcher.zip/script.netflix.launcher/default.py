import xbmc, os, xbmcaddon, subprocess

addon = xbmcaddon.Addon()
script_path = addon.getAddonInfo('path')
script_file = 'netflixlauncher.exe'
script = os.path.join(script_path, script_file)
xbmc.executebuiltin("XBMC.PlayerControl(Stop)")
subprocess.Popen(script, shell=True, close_fds=True)